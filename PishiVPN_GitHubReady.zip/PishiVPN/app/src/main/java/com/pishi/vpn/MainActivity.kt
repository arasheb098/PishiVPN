package com.pishi.vpn

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.pishi.vpn.ui.theme.PishiVPNTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PishiVPNTheme {
                Surface(color = Color(0xFFD4F1F4)) {
                    VPNHomeScreen()
                }
            }
        }
    }
}