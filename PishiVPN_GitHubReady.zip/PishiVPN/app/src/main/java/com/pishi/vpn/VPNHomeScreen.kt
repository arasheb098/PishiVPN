package com.pishi.vpn

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun VPNHomeScreen() {
    var isConnected by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceEvenly
    ) {
        Text(
            text = "PishiVPN",
            fontSize = 36.sp,
            color = Color(0xFFB85FC7),
            fontWeight = FontWeight.ExtraBold
        )

        Image(
            painter = painterResource(id = R.drawable.ic_power),
            contentDescription = "Power",
            modifier = Modifier
                .size(150.dp)
                .clickable { isConnected = !isConnected }
                .background(Color(0xFFEBFFFF), CircleShape)
                .padding(30.dp)
        )

        Text(
            text = if (isConnected) "Connected" else "Disconnected",
            fontSize = 20.sp,
            fontWeight = FontWeight.Medium,
            color = if (isConnected) Color(0xFF4CAF50) else Color.DarkGray
        )

        Button(
            onClick = { isConnected = !isConnected },
            shape = RoundedCornerShape(50),
            modifier = Modifier
                .fillMaxWidth(0.6f)
                .height(55.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE0FBFC))
        ) {
            Text(
                text = if (isConnected) "DISCONNECT" else "CONNECT",
                fontSize = 16.sp,
                color = Color(0xFF0A2F43),
                fontWeight = FontWeight.Bold
            )
        }

        Image(
            painter = painterResource(id = R.drawable.ic_cat),
            contentDescription = "Kitten",
            modifier = Modifier.size(120.dp)
        )
    }
}