This is a test-ready version of PishiVPN.

- Package name: com.pishi.vpn
- VPN protocol: WireGuard (with test config)
- UI: Jetpack Compose
- Files: Add your real WireGuard config to drawable/client.conf
- You need to add actual drawable resources: ic_power.png and ic_cat.png